package ru.mirea.prac10;

public class ImageDocument implements IDocument {
}
