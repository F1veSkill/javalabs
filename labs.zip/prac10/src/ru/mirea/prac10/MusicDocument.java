package ru.mirea.prac10;

public class MusicDocument implements IDocument{
}
