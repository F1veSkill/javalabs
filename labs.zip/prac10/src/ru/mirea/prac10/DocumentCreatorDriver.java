package ru.mirea.prac10;

public class DocumentCreatorDriver {

    public static void main(String[] args) {
        new DocumentCreatorGUI();
    }
}
