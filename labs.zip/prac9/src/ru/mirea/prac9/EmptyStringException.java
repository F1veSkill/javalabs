package ru.mirea.prac9;

public class EmptyStringException extends Exception {}
