package ru.mirea.prac9;

public class StudentNotFoundException extends RuntimeException{}
