package ru.mirea.prac9;

public class LabClassDriver {

    public static void main(String[] args) {
        new LabClassUI();
    }
}