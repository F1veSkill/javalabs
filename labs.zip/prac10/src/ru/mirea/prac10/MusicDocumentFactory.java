package ru.mirea.prac10;

public class MusicDocumentFactory implements IDocumentFactory {
    @Override
    public IDocument createNew(String name) {
        return null;
    }

    @Override
    public IDocument createOpen(String name) {
        return null;
    }
}
