package ru.mirea.prac10;

public interface IDocument {
}
