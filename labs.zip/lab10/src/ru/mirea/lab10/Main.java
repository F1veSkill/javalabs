package ru.mirea.lab10;

public class Main {

    public static void main(String[] args) {
        MyArray<Integer> arr = new MyArray<>();
        arr.setArr(new Integer[]{2, 3, 3, 4, 1, 1});
    }
}
